#include "ege.h"
#include "graphics.h"
#include <iostream>

int main() {
    initgraph(64, 480);
    circle(200, 200, 200);
    getch();
    closegraph();
    return 0;
}