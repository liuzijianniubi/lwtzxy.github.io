#include <iostream>
#include <cstdio>
#include <cstring>
#include <cstdlib>
#include <vector>
#include <fstream>
using namespace std;

string err_msg[]=
{
    "��ʶ���Ƿ�",
    "��ʶ�����������ֿ�ͷ",
    "����ȱ��=",
    "�����ַ�����"
};
int row = 1, col = 0;

void error(int n, char ch)
{
    cout << "Error, " << err_msg[n] << " " << ch << endl;
}

string Concat(char ch, string& strToken)
{
    strToken += ch;
    return strToken;
}

bool IsLetter(char ch)
{
    if((ch >= 'A' && ch <= 'Z') || (ch >= 'a' && ch <= 'z'))
    {
        return true;
    }
    else
    {
        return false;
    }
}

bool IsDigit(char ch)
{
    if(ch >= '0' && ch <= '9')
    {
        return true;
    }
    else
    {
        return false;
    }
}

int Reserve(string &strToken, vector<string> table)
{
    int i = 1;
    for(i;i < table.size();i++)
    {
        if(strToken == table[i])
        {
            return i;
        }
    }
    return 0;
}

int insertID(string &strToken, vector<string> &table)
{
    table.push_back(strToken);
    return table.size();
}

int insertConst(string &strToken, vector<int> &table)
{
    table.push_back(atoi(&strToken[0]));
    return table.size();
}

void cifa();

int main()
{
    cifa();
}
void cifa()
{
    string Table[] =
    {"", "program", "const", "var", "procedure",
     "begin", "end", "if", "then", "while", "do",
     "call", "read", "write", "odd"};
    vector<string> reserve_table(Table, Table + 15);
    vector<string> sign_table;
    vector<int> const_table;

    ifstream infile("code1.txt");
    if(!infile)
    {
        cout << "can not open codeFile!" << endl;
    }
    ofstream outfile("temp.txt");
    if(!outfile)
    {
        cout << "can not open tempFile!" << endl;
    }

    char ch;
    int code, value;
    string strToken;

    infile.get(ch);
    col++;

    if(ch == ' ')
    {
        while(!infile.eof())
        {
            if(IsLetter(ch) || IsDigit(ch))
            {
                infile.seekg(-1, ios::cur);
                col--;
                break;
            }
            else
            {
                infile.get(ch);
                col++;
            }
        }
    }

    while(!infile.eof())
    {
        strToken = "";
        if(IsLetter(ch))
        {
            while(IsLetter(ch) || IsDigit(ch))
            {
                Concat(ch, strToken);
                infile.get(ch);
                if(!infile) break;
                col++;
            }
            
            code = Reserve(strToken, reserve_table);
            if(code == 0)
            {
                value = Reserve(strToken, sign_table);
                if(value == 0)
                {
                    value = insertID(strToken, sign_table);
                    outfile << "(" << strToken << ", $ID, " << value << ")" << endl;
                }
                else
                {
                    outfile << "(" << strToken << ", $ID, " << value << ")" << endl;
                }
            }
            else
            {
                outfile << "(" << strToken << ", -, " << code << ")" << endl;
                if(code == 7)
                {
                    if(ch != ' ')
                    {
                        cout << row << "��" << col << "��:";
                        error(0, ch);//
                    }
                }
            }
        }
        else if(IsDigit(ch))
        {
            while(IsDigit(ch))
            {
                Concat(ch, strToken);
                infile.get(ch);
                if(!infile) break;
                col++;
            }
            if(IsLetter(ch))
            {
                cout << row << "��" << col << "��:";
                error(1, ch);//
            }
            else
            {
                value = insertConst(strToken, const_table);
                outfile << "(" << strToken << ", $INT, " << value << ")" << endl;
            }
        }
        else if(ch == '=')
        {
            outfile << "($=, -)" << endl;
            infile.get(ch);
            col++;
        }
        else if(ch == '+')
        {
            outfile << "($+, -)" << endl;
            infile.get(ch);
            col++;
        }
        else if(ch == '-')
        {
            outfile << "($-, -)" << endl;
            infile.get(ch);
            col++;
        }
        else if(ch == '*')
        {
            infile.get(ch);
            if(ch == '*') outfile << "($POWER, -)" << endl;
            infile.seekg(-1, ios::cur);
            col--;
            outfile << "($STAR, -)" << endl;
            infile.get(ch);
            col++;
        }
        else if(ch == '/')
        {
            outfile << "($/, -)" << endl;
            infile.get(ch);
            col++;
        }
        else if(ch == '<')
        {
            infile.get(ch);
            col++;
            if(ch == '>')
            {
                outfile << "($<>, -)" << endl;
                infile.get(ch);
                col++;
            }
            else if(ch == '=')
            {
                outfile << "($<=, -)" << endl;
                infile.get(ch);
                col++;
            }
            else
            {
                outfile << "($<, -)" << endl;
            }
        }
        else if(ch == '>')
        {
            infile.get(ch);
            col++;
            if(ch == '=')
            {
                outfile << "($>=, -)" << endl;
                infile.get(ch);
                col++;
            }
            else
            {
                outfile << "($>, -)" << endl;
            }
        }
        else if(ch == ';')
        {
            outfile << "($;, -)" << endl;
            infile.get(ch);
            col++;
        }
        else if(ch == '(')
        {
            outfile << "($(, -)" << endl;
            infile.get(ch);
            col++;
        }
        else if(ch == ')')
        {
            outfile << "($), -)" << endl;
            infile.get(ch);
            col++;
        }
        else if(ch == '{')
        {
            outfile << "(${, -)" << endl;
            infile.get(ch);
            col++;
        }
        else if(ch == '}')
        {
            outfile << "($}, -)" << endl;
            infile.get(ch);
            col++;
        }
        else if(ch == '\n' || ch == ' ' || ch == 9)
        {
            if(ch == '\n')
            {
                row++;
                col = 0;
            }
            infile.get(ch);
            col++;
        }
        else if(ch == ':')
        {
            infile.get(ch);
            col++;
            if(ch == '=')
            {
                outfile << "($:=, -)" << endl;
                infile.get(ch);
                col++;
            }
            else
            {
                cout << row << "��" << col << "��:";
                error(2, ch);//
                infile.get(ch);
                col++;
            }
        }
        else if(ch == ',')
        {
            outfile << "($,, -)" << endl;
			infile.get(ch);
			col++;
        }
        else
        {
            cout << row << "��" << col << "��:";
            error(3, ch);//
            infile.get(ch);
            col++;
        }
    }
    infile.close();
    outfile.close();
}