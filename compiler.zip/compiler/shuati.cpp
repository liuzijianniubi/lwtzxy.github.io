#include <iostream>
#include <vector>
#include <map>
#include <cstring>
using namespace std;

vector<bool> caml(vector<string> &queries, string pattern) {
    int n = queries.size();
    vector<bool> ans(n, true);
    for(int i=0;i < n;i++) {
        int p = 0;
        for(auto c : queries[i]) {
            if(p < pattern.size() && pattern[p] == c) {
                p++;
            } else if(isupper(c)) {
                ans[i] = false;
                break;
            }
        }
        if(p < pattern.size()) {
            ans[i] = false;
        }
    }
    return ans;
}

int main() {
    vector<string> queries{"FooBar","FooBarTest","FootBall","FrameBuffer","ForceFeedBack"};
    string pattern = "FB";
    vector<bool> b = caml(queries, pattern);
    for(auto i:b) {
        cout << i << " ";
    }
}