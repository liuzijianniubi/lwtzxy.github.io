#pragma once
#include <iostream>
#include <cstdio>
#include <cstring>
#include <cstdlib>
#include <vector>
#include <fstream>
using namespace std;

string err_msg[]=
{
    "��ʶ���Ƿ�",
    "��ʶ�����������ֿ�ͷ",
    "����ȱ��=",
    "�����ַ�����"
};
int row = 1, col = 0;
int err = 0;

struct token
{
    string strToken;
    int row, col;
    int kind;//1-id, 2-const, 3-other, 4-key
};

void error(int n, char ch)
{
    err++;
    cout << "Error" << err << ", " << err_msg[n] << " " << ch << endl;
}

string Concat(char ch, string& strToken)
{
    strToken += ch;
    return strToken;
}

bool IsLetter(char ch)
{
    if((ch >= 'A' && ch <= 'Z') || (ch >= 'a' && ch <= 'z'))
    {
        return true;
    }
    else
    {
        return false;
    }
}

bool IsDigit(char ch)
{
    if(ch >= '0' && ch <= '9')
    {
        return true;
    }
    else
    {
        return false;
    }
}

int Reserve(string &strToken, vector<string> table)
{
    int i = 1;
    for(i;i < table.size();i++)
    {
        if(strToken == table[i])
        {
            return i;
        }
    }
    return 0;
}

int insertID(string &strToken, vector<string> &table)
{
    table.push_back(strToken);
    return table.size();
}

int insertConst(string &strToken, vector<int> &table)
{
    table.push_back(atoi(&strToken[0]));
    return table.size();
}

void cifa(vector<token> &T)
{
    string Table[] =
    {"", "program", "const", "var", "procedure",
     "begin", "end", "if", "then", "else", "while", "do",
     "call", "read", "write", "odd"};
    vector<string> reserve_table(Table, Table + 15);
    vector<string> sign_table;
    vector<int> const_table;
    token t;

    ifstream infile("code5.txt");
    if(!infile)
    {
        cout << "can not open codeFile!" << endl;
    }
    ofstream outfile("temp.txt");
    if(!outfile)
    {
        cout << "can not open tempFile!" << endl;
    }

    char ch;
    int code, value;
    string strToken;

    infile.get(ch);
    col++;

    if(ch == ' ')
    {
        while(!infile.eof())
        {
            if(IsLetter(ch) || IsDigit(ch))
            {
                infile.seekg(-1, ios::cur);
                col--;
                break;
            }
            else
            {
                infile.get(ch);
                col++;
            }
        }
    }

    while(!infile.eof())
    {
        strToken = "";
        if(IsLetter(ch))
        {
            while(IsLetter(ch) || IsDigit(ch))
            {
                Concat(ch, strToken);
                infile.get(ch);
                if(!infile) break;
                col++;
            }
            
            code = Reserve(strToken, reserve_table);
            if(code == 0)
            {
                value = Reserve(strToken, sign_table);
                if(value == 0)
                {
                    value = insertID(strToken, sign_table);
                    outfile << "(" << strToken << ", $ID, " << value << ")" << endl;

                    t.strToken = strToken;
                    t.row = row;
                    t.col = col - strToken.length();
                    t.kind = 1;
                    T.push_back(t);
                }
                else
                {
                    outfile << "(" << strToken << ", $ID, " << value << ")" << endl;

                    t.strToken = strToken;
                    t.row = row;
                    t.col = col - strToken.length();
                    t.kind = 1;
                    T.push_back(t);
                }
            }
            else
            {
                outfile << "(" << strToken << ", -, " << code << ")" << endl;

                t.strToken = strToken;
                t.row = row;
                t.col = col - strToken.length();
                t.kind = 4;
                T.push_back(t);

                if(code == 7)
                {
                    if(ch != ' ')
                    {
                        cout << row << "��" << col << "��:";
                        error(0, ch);//
                    }
                }
            }
        }
        else if(IsDigit(ch))
        {
            while(IsDigit(ch))
            {
                Concat(ch, strToken);
                infile.get(ch);
                if(!infile) break;
                col++;
            }
            if(IsLetter(ch))
            {
                cout << row << "��" << col << "��:";
                error(1, ch);//
            }
            else
            {
                value = insertConst(strToken, const_table);
                outfile << "(" << strToken << ", $INT, " << value << ")" << endl;

                t.strToken = strToken;
                t.row = row;
                t.col = col - strToken.length();
                t.kind = 2;
                T.push_back(t);
            }
        }
        else if(ch == '=')
        {
            outfile << "($=, -)" << endl;
            
            t.strToken = "=";
            t.row = row;
            t.col = col;
            t.kind = 3;
            T.push_back(t);

            infile.get(ch);
            col++;
        }
        else if(ch == '+')
        {
            outfile << "($+, -)" << endl;
            
            t.strToken = "+";
            t.row = row;
            t.col = col;
            t.kind = 3;
            T.push_back(t);

            infile.get(ch);
            col++;
        }
        else if(ch == '-')
        {
            outfile << "($-, -)" << endl;
            
            t.strToken = "-";
            t.row = row;
            t.col = col;
            t.kind = 3;
            T.push_back(t);

            infile.get(ch);
            col++;
        }
        else if(ch == '*')
        {
            infile.get(ch);
            col++;
            if(ch == '*')
            {
                outfile << "($POWER, -)" << endl;
            
                t.strToken = "**";
                t.row = row;
                t.col = col;
                t.kind = 3;
                T.push_back(t);

                infile.get(ch);
                col++;
            }
            else
            {
                outfile << "($STAR, -)" << endl;
            
                t.strToken = "*";
                t.row = row;
                t.col = col;
                t.kind = 3;
                T.push_back(t);

            }
        }
        else if(ch == '/')
        {
            outfile << "($/, -)" << endl;
            
            t.strToken = "/";
            t.row = row;
            t.col = col;
            t.kind = 3;
            T.push_back(t);

            infile.get(ch);
            col++;
        }
        else if(ch == '<')
        {
            infile.get(ch);
            col++;
            if(ch == '>')
            {
                outfile << "($<>, -)" << endl;
            
                t.strToken = "<>";
                t.row = row;
                t.col = col;
                t.kind = 3;
                T.push_back(t);

                infile.get(ch);
                col++;
            }
            else if(ch == '=')
            {
                outfile << "($<=, -)" << endl;
            
                t.strToken = "<=";
                t.row = row;
                t.col = col;
                t.kind = 3;
                T.push_back(t);

                infile.get(ch);
                col++;
            }
            else
            {
                outfile << "($<, -)" << endl;
            
                t.strToken = "<";
                t.row = row;
                t.col = col;
                t.kind = 3;
                T.push_back(t);

            }
        }
        else if(ch == '>')
        {
            infile.get(ch);
            col++;
            if(ch == '=')
            {
                outfile << "($>=, -)" << endl;
            
                t.strToken = ">=";
                t.row = row;
                t.col = col;
                t.kind = 3;
                T.push_back(t);

                infile.get(ch);
                col++;
            }
            else
            {
                outfile << "($>, -)" << endl;
            
                t.strToken = ">";
                t.row = row;
                t.col = col;
                t.kind = 3;
                T.push_back(t);

            }
        }
        else if(ch == ';')
        {
            outfile << "($;, -)" << endl;
            
            t.strToken = ";";
            t.row = row;
            t.col = col;
            t.kind = 3;
            T.push_back(t);

            infile.get(ch);
            col++;
        }
        else if(ch == '(')
        {
            outfile << "($(, -)" << endl;
            
            t.strToken = "(";
            t.row = row;
            t.col = col;
            t.kind = 3;
            T.push_back(t);

            infile.get(ch);
            col++;
        }
        else if(ch == ')')
        {
            outfile << "($), -)" << endl;
            
            t.strToken = ")";
            t.row = row;
            t.col = col;
            t.kind = 3;
            T.push_back(t);

            infile.get(ch);
            col++;
        }
        else if(ch == '{')
        {
            outfile << "(${, -)" << endl;
            
            t.strToken = "{";
            t.row = row;
            t.col = col;
            t.kind = 3;
            T.push_back(t);

            infile.get(ch);
            col++;
        }
        else if(ch == '}')
        {
            outfile << "($}, -)" << endl;
            
            t.strToken = "}";
            t.row = row;
            t.col = col;
            t.kind = 3;
            T.push_back(t);

            infile.get(ch);
            col++;
        }
        else if(ch == '\n' || ch == ' ' || ch == 9)
        {
            if(ch == '\n')
            {
                row++;
                col = 0;
            }
            infile.get(ch);
            col++;
        }
        else if(ch == ':')
        {
            infile.get(ch);
            col++;
            if(ch == '=')
            {
                outfile << "($:=, -)" << endl;
            
                t.strToken = ":=";
                t.row = row;
                t.col = col;
                t.kind = 3;
                T.push_back(t);

                infile.get(ch);
                col++;
            }
            else
            {
                cout << row << "��" << col << "��:";
                error(2, ch);//
                infile.get(ch);
                col++;
            }
        }
        else if(ch == ',')
        {
            outfile << "($,, -)" << endl;
            
            t.strToken = ",";
            t.row = row;
            t.col = col;
            t.kind = 3;
            T.push_back(t);

			infile.get(ch);
			col++;
        }
        else
        {
            cout << row << "��" << col << "��:";
            error(3, ch);//
            
            t.strToken = "NULL";
            t.row = row;
            t.col = col;
            t.kind = 3;
            T.push_back(t);

            infile.get(ch);
            col++;
        }
    }
    infile.close();
    outfile.close();
}