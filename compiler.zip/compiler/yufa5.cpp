#include "cifa.h"
#include <cstdio>
using namespace std;

#define NULL_DEF -100//��NULL

int goal = 0;

vector<token> t;
int t_index = 0;
string op[] = {
    "LIT",
    "LOD",
    "STO",
    "CAL",
    "INT",
    "JMP",
    "JPC",
    "WRT",
    "OPR",
    "RED"
};
enum opcode
{
    LIT,
    LOD,
    STO,
    CAL,
    INT,
    JMP,
    JPC,
    WRT,
    OPR,
    RED
};

typedef struct
{
    int f;
    int l;
    int a;
}code;
vector<code> mid_code;//�м����
typedef struct
{
    string name;
    int kind;//1-variable 2-constant 3-procedure
    int value;
    int level;
    int address;
    int size;
}namelist;
vector<namelist> table;//���ű�
int level = 0;
int address = 0;
int dx = 3;//��¼���ٿռ������Ĭ����3��SL DL RA

class yufa
{
    public:
    //����
    void error(token _t, string msg)
    {
        goal = 1;
        cout << _t.row << "��" << _t.col << "��:Error" << err << ", " << _t.strToken << msg << endl;
        err++;
    }
    //���ôʻ�
    token getsym()
    {
        if(t_index > t.size())
        {
            exit(0);//!
        }
        token _token = t[t_index];
        t_index++;
        return _token;
    }
    //��¼���ű�
    void enter(string name, int kind, int value, int lev, int address, int size)
    {
        namelist _table;
        _table.name = name;
        _table.kind = kind;
        _table.value = value;
        _table.level = lev;
        _table.address = address;
        _table.size = size;

        table.push_back(_table);
    }
    //�����м����
    void gen(int f, int l, int a)
    {
        code _pcode;
        _pcode.f = f;
        _pcode.l = l;
        _pcode.a = a;
        mid_code.push_back(_pcode);
    }
    //��ѯ���ű�
    int find_table(string val, int lev)
    {
        int index=table.size() - 1;
        for(index;index>=0;index--)
        {
            if(table[index].name == val)
            {
                if(table[index].level <= lev)
                    return index;
            }
        }
        return -1;
    }
    //<prog> �� program <id>��<block>
    void prog()
    {
        token _t = getsym();
        if(_t.strToken == "program")
        {
            _t = getsym();
            if(_t.kind == 1)
            {
                _t = getsym();
                if(_t.strToken == ";")
                {
                    block(0);
                }
                else
                {
                    error(_t, "����ȱ��';'");
                }
            }
            else
            {
                error(_t, "�﷨����, ȱ�ٳ�������");
            }
        }
        else
        {
            error(_t, "ȱ�ٹؼ���'program'");
        }
    }
    //<block> �� [<condecl>][<vardecl>][<proc>]<body>
    void block(int dx0)
    {
        dx = 3 + dx0;
        int cx1 = mid_code.size();
        int idSize;
        gen(JMP, 0, 0);
        token _t = getsym();
        if(_t.strToken == "const")
        {
            _const();
            _t = getsym();
            while(_t.strToken == ",")
            {
                _const();
                _t = getsym();
            }
            if(_t.strToken == ";")
            {
                _t = getsym();
            }
            else
            {
                error(_t, "ȱ��';'");
            }
        }
        if(_t.strToken == "var")
        {
            _t = getsym();
            if(_t.kind == 1)
            {
                enter(_t.strToken, 1, NULL_DEF, level, dx, NULL_DEF);
                dx++;
                _t = getsym();
            }
            else
            {
                error(_t, "'var'������Ҫ����ʶ��");
            }
            while(_t.strToken == ",")
            {
                _t = getsym();
                if(_t.kind == 1)
                {
                    enter(_t.strToken, 1, NULL_DEF, level, dx, NULL_DEF);
                    dx++;
                    _t = getsym();
                    continue;
                }
            }
            if(_t.strToken == ";")
            {
                _t = getsym();
            }
            else
            {
                error(_t, "ȱ��';'");
            }
        }
        while(_t.strToken == "procedure")
        {
            _t = getsym();

            token temp;
            temp = _t;

            if(_t.kind != 1)
            {
                error(_t, "���������Ǳ�ʶ��");
            }
            _t = getsym();

            int goal = 0; //�ж��Ƿ����(id, id)
            //(id, id)
            if(_t.strToken == "(")
            {
                idSize = 0;
                goal = 1;

                do
                {
                    _t = getsym();
                    if(_t.kind != 1)
                    {
                        error(_t, "���Ǳ�ʶ��");
                    }
                    idSize++;
                    enter(_t.strToken, 1, NULL_DEF, level+1, idSize + 2, NULL_DEF);
                    _t = getsym();
                } while(_t.strToken == ",");
                if(_t.strToken != ")")
                {
                    error(_t, "ȱ�ٹؼ���')'");
                    t_index--;
                    _t = getsym();
                }
                else
                {
                    enter(temp.strToken, 3, NULL_DEF, level, mid_code.size(), idSize);
                    _t = getsym();
                }
            }

            if(_t.strToken != ";")
            {
                error(_t, "ȱ��';'");
                t_index--;
            }
            if(goal == 0) enter(temp.strToken, 3, NULL_DEF, level, mid_code.size(), 0); //�޲����ͺ���

            level++;
            int cur_Dx = dx;//��ǰ�����ĸ���
            block(idSize);
            level--;
            dx = cur_Dx;
            _t = getsym();
            if(_t.strToken == ";")
            {
                _t = getsym();
            }
            else break;
        }
        t_index--;

        code instruction;
        instruction.f = JMP;
        instruction.l = 0;
        instruction.a = mid_code.size();
        mid_code[cx1] = instruction;
        gen(INT, 0, dx);//���ٿռ�
        body();
        gen(OPR, 0, 0);//���ص��õ㣬��ջ
    }
    //<const> �� <id>:=<integer>
    void _const()
    {
        token _t = getsym();
        string variable = _t.strToken;
        if(_t.kind == 1)
        {
            token _tt = _t;
            _t = getsym();
            if(_t.strToken == ":=")
            {
                _t = getsym();
                if(_t.kind == 2)
                {
                    enter(variable, 2, atoi(_t.strToken.c_str()), level, NULL_DEF, NULL_DEF);
                }
                else
                {
                    error(_t, "':='������Ҫ������");
                }
            }
            else
            {
                error(_t, "ȱ��':='");
            }
        }
        else
        {
            error(_t, "ȱ�ٱ�ʶ��");
        }
    }
    //<body> �� begin <statement>{;<statement>}end
    void body()
    {
        token _t = getsym();
        if(_t.strToken != "begin")
        {
            error(_t, "ȱ��'begin'");
            t_index--;
        }
        statement();
        _t = getsym();
        while(_t.strToken == ";")
        {
            statement();
            _t = getsym();
        }
        if(_t.strToken != "end")
        {
            error(_t, "ȱ��'end'");
            t_index--;
        }
    }
    // <statement> �� <id> := <exp>               
	// 	      |if <lexp> then <statement>[else <statement>]
    //         	      |while <lexp> do <statement>
    //                       |call <id>��[<exp>{,<exp>}]��
    //                      |<body>
    //                      |read (<id>{��<id>})
    //                      |write (<exp>{,<exp>})
    void statement()
    {
        token _t = getsym();
        if(_t.strToken == "end")
        {
            error(_t, ";�����");
            t_index--;
            return;
        }
        // <id> := <exp> 
        if(_t.kind == 1)
        {
            int i = find_table(_t.strToken, level);
            if(i == -1)
            {
                error(_t, "δ����");
            }
            else if(table[i].kind != 1)
            {
                error(_t, "����һ������");
            }
            _t = getsym();
            if(_t.strToken != ":=")
            {
                error(_t, "ȱ��':='");
                t_index--;
            }
            expression();

            if(i != -1)
            {
                gen(STO, level - table[i].level, table[i].address);
            }
        }
        // if <lexp> then <statement>[else <statement>]
        else if(_t.strToken == "if")
        {
            lexp();
            _t = getsym();
            if(_t.strToken != "then")
            {
                error(_t, "ȱ�ٹؼ���'then");
                t_index--;
            }
            int cx2 = mid_code.size();
            gen(JPC, 0, 0);
            statement();

            code instruction;
            instruction.f = JPC;
            instruction.l = 0;
            instruction.a = mid_code.size() + 1;
            mid_code[cx2] = instruction;
            _t = getsym();
            if(_t.strToken == "else")
            {
                int cx1 = mid_code.size();
                gen(JMP, 0, 0);
                statement();
                //����if��������ַ
                code instruction;
                instruction.f = JMP;
                instruction.l = 0;
                instruction.a = mid_code.size();
                mid_code[cx1] = instruction;
            }
            else t_index--;
        }
        // while <lexp> do <statement>
        else if(_t.strToken == "while")
        {
            int jmp_addr = mid_code.size();
            lexp();
            _t = getsym();
            if(_t.strToken != "do")
            {
                error(_t, "ȱ�ٹؼ���'do'");
                t_index--;
            }
            int cx2 = mid_code.size();
            gen(JPC, 0, 0);
            statement();
            gen(JMP, 0, jmp_addr);

            code instruction;
            instruction.f = JPC;
            instruction.l = 0;
            instruction.a = mid_code.size();
            mid_code[cx2] = instruction;
        }
        // call <id>��[<exp>{,<exp>}])
        else if(_t.strToken == "call")
        {
            _t = getsym();
            if(_t.kind != 1)
            {
                error(_t, "�����������Ǳ�ʶ��");
            }

            int i = find_table(_t.strToken, level);
            if(i == -1)
            {
                error(_t, "����δ����");
            }
            else if(table[i].kind == 3)
            {
                _t = getsym();
                if(_t.strToken == "(")
                {
                    int idSize=0, index=i - table[i].size;
                    do
                    {
                        expression();
                        idSize++;
                        if(level == table[i].level)
                            gen(STO, -1, table[index].address);
                        else
                            gen(STO, -(level - table[i].level), table[index].address);
                        index++;
                        _t = getsym();
                    } while (_t.strToken == ",");
                    if(idSize < table[i].size)
                    {
                        error(_t, "����̫��");
                    }
                    else if(idSize > table[i].size)
                    {
                        error(_t, "����̫��");
                    }
                    else
                    {
                        if(_t.strToken != ")")
                        {
                            error(_t, "ȱ�ٹؼ���')'");
                            t_index--;
                        }
                    }
                }
                else
                    t_index--;
                gen(CAL, level - table[i].level, table[i].address);
            }
            else
            {
                error(_t, "���Ǻ�����");
            }
            
        }
        //read
        else if(_t.strToken == "read")
        {
            _t = getsym();
            if(_t.strToken == "(")
            {
                do
                {
                    _t = getsym();
                    if(_t.kind == 1)
                    {
                        int i = find_table(_t.strToken, level);
                        if(i == -1)
                        {
                            error(_t, "δ����");
                        }
                        else if(table[i].kind == 1)
                        {
                            gen(RED, 0, 0);//
                            gen(STO, level - table[i].level, table[i].address);
                        }
                        else
                        {
                            error(_t, "���Ǳ���");
                        }
                    }
                    else
                    {
                        error(_t, "���Ǳ�ʶ��");
                    }
                    _t = getsym();
                } while(_t.strToken == ",");
                if(_t.strToken != ")")
                {
                    error(_t, "ȱ�ٹؼ���')'");
                    t_index--;
                }
            }
            else
            {
                error(_t, "ȱ�ٹؼ���'('");
                t_index--;
            }
        }
        //write
        else if(_t.strToken == "write")
        {
            _t = getsym();
            if(_t.strToken == "(")
            {
                do
                {
                    expression();
                    gen(WRT, 0, 0);
                    gen(OPR, 0, 15);
                    _t = getsym();
                } while(_t.strToken == ",");
                if(_t.strToken != ")")
                {
                    error(_t, "ȱ�ٹؼ���')'");
                    t_index--;
                }
            }
            else
            {
                error(_t, "ȱ�ٹؼ���'('");
                t_index--;
            }
        }
        //body()
        else
        {
            t_index--;
            body();
        }
    }
    // <exp> �� [+|-]<term>{<aop><term>}
    void expression()
    {
        token _t = getsym();
        if(_t.strToken == "+" || _t.strToken == "-")
        {
            term();
            if(_t.strToken == "-")
            {
                gen(OPR, 0, 1);
            }
        }
        else
        {
            t_index--;
            term();
        }
        _t = getsym();
        while(_t.strToken == "+" || _t.strToken == "-")
        {
            term();
            if(_t.strToken == "+")
            {
                gen(OPR, 0, 2);
            }
            else if(_t.strToken == "-")
            {
                gen(OPR, 0, 3);
            }
            _t = getsym();
        }
        t_index--;
    }
    // <term> �� <factor>{<mop><factor>}
    void term()
    {
        factor();
        token _t = getsym();
        while(_t.strToken == "*" || _t.strToken == "/")
        {
            factor();
            if(_t.strToken == "*")
            {
                gen(OPR, 0, 4);
            }
            else if(_t.strToken == "/")
            {
                gen(OPR, 0, 5);
            }
            _t = getsym();
        }
        t_index--;
    }
    // <factor>��<id>|<integer>|(<exp>)
    void factor()
    {
        token _t = getsym();
        if(_t.kind == 1)
        {
            int i = find_table(_t.strToken, level);
            if(i == -1)
            {
                error(_t, "δ����");
            }
            else
            {
                if(table[i].kind == 2)
                {
                    gen(LIT, 0, table[i].value);
                }
                else if(table[i].kind == 1)
                {
                    gen(LOD, level - table[i].level, table[i].address);
                }
                else if(table[i].kind == 3)
                {
                    error(_t, "Ϊ����������");
                }
            }
        }
        else if(_t.kind == 2)
        {
            gen(LIT, 0, atoi(_t.strToken.c_str()));
        }
        else if(_t.strToken == "(")
        {
            expression();
            _t = getsym();
            if(_t.strToken != ")")
            {
                error(_t, "ȱ��������");
                t_index--;
            }
        }
    }
    // <lexp> �� <exp> <lop> <exp>|odd <exp>
    void lexp()
    {
        token _t = getsym();
        if(_t.strToken == "odd")
        {
            expression();
            gen(OPR, 0, 6);
        }
        else
        {
            t_index--;
            expression();
            _t = getsym();
            if(_t.strToken != "=" && _t.strToken != "<>" &&
               _t.strToken != "<" && _t.strToken != "<=" &&
               _t.strToken != ">" && _t.strToken != ">=")
            {
                error(_t, "ȱ�ٱȽ������");
                t_index--;
            }
            expression();
            if(_t.strToken == "=")
            {
                gen(OPR, 0, 7);
            }
            else if(_t.strToken == "<>")
            {
                gen(OPR, 0, 8);
            }
            else if(_t.strToken == "<")
            {
                gen(OPR, 0, 9);
            }
            else if(_t.strToken == ">=")
            {
                gen(OPR, 0, 10);
            }
            else if(_t.strToken == ">")
            {
                gen(OPR, 0, 11);
            }
            else if(_t.strToken == "<=")
            {
                gen(OPR, 0, 12);
            }
        }
    }
    
    int stack[8000];//����ջ SL DL RA
    int get_sl(int B, int lev)
    {
        int res_B = B;
        while(lev > 0)
        {
            res_B = stack[res_B];
            lev--;
        }
        return res_B;
    }
    void interpreter()
    {
        for(int i=0;i<8000;i++) stack[i] = 0;
        int B = 0;//����ַ�Ĵ���
        int T = 0;//ջ��ָʾ���Ĵ���
        code I;//ָ��Ĵ���
        int P = 0;//�����ַ�Ĵ���

        cout << "��ʼ����ִ��P����..." << endl;
        I = mid_code[P];
        P++;
        while(P!=0)
        {
            if(I.f == JMP)//ֱ����ת
            {
                P = I.a;
            }
            else if(I.f == JPC)//ջ��Ϊ0��ת
            {
                T--;
                if(stack[T] == 0)
                {
                    P = I.a;
                }
            }
            else if(I.f == INT)//���ٿռ�
            {
                T += I.a;
            }
            else if(I.f == LOD)
            {
                stack[T] = stack[get_sl(B, I.l) + I.a];
                T++;
            }
            else if(I.f == STO)
            {
                T--;
                if(I.l == -1) stack[T + I.a] = stack[T];
                else
                    stack[get_sl(B, I.l) + I.a] = stack[T];
            }
            else if(I.f == LIT)
            {
                stack[T] = I.a;
                T++;
            }
            else if(I.f == CAL)//call
            {
                stack[T] = get_sl(B, I.l);
                stack[T + 1] = B;
                stack[T + 2] = P;
                B = T;
                P = I.a;
            }
            else if(I.f == WRT)//write
            {
                cout << "���:" << endl;
                cout << stack[T - 1] << endl;
                T--;
            }
            else if(I.f == OPR)
            {
                if(I.a == 0)//���̵��ý��������ص��õ㲢��ջ
                {
                    T = B;
                    P = stack[T + 2];
                    B = stack[T + 1];
                }
                else if(I.a == 1)//ȡ��
                {
                    stack[T - 1] = -stack[T - 1];
                }
                else if(I.a == 2)//�ӷ�
                {
                    T--;
                    stack[T - 1] = stack[T - 1] + stack[T];
                }
                else if(I.a == 3)//����
                {
                    T--;
                    stack[T - 1] = stack[T - 1] - stack[T];
                }
                else if(I.a == 4)//�˷�
                {
                    T--;
                    stack[T - 1] = stack[T - 1] * stack[T];
                }
                else if(I.a == 5)//����
                {
                    
                    T--;
                    if(stack[T] == 0)
                    {
                        cout << "error, NaN����!" << endl;
                        P = mid_code.size();
                    }
                    else
                        stack[T - 1] = (int)(stack[T - 1] / stack[T]);
                }
                else if(I.a == 6)//��ż
                {
                    stack[T - 1] = stack[T - 1] % 2;
                }
                else if(I.a == 7)//==
                {
                    T--;
                    stack[T - 1] = (stack[T - 1] == stack[T]);
                }
                else if(I.a == 8)//!=
                {
                    T--;
                    stack[T - 1] = (stack[T - 1] != stack[T]);
                }
                else if(I.a == 9)//<
                {
                    T--;
                    stack[T - 1] = (stack[T - 1] < stack[T]);
                }
                else if(I.a == 10)//>=
                {
                    T--;
                    stack[T - 1] = (stack[T - 1] >= stack[T]);
                }
                else if(I.a == 11)//>
                {
                    T--;
                    stack[T - 1] = (stack[T - 1] > stack[T]);
                }
                else if(I.a == 12)//<=
                {
                    T--;
                    stack[T - 1] = (stack[T - 1] <= stack[T]);
                }
            }
            else if(I.f == RED)//read
            {
                cout << "������: " << endl;
                cin >> stack[T];
                T++;
            }
            
            I = mid_code[P];
            if(P == 0)
            {
                break;
            }
            P++;
        }
    }
    void listcode()
    {
        cout << "listcode:" << endl;
        for(int i=0;i<mid_code.size();i++)
        {
            printf("%5d ", i);
            cout << op[mid_code[i].f] << "\t";
            printf("%d\t%d\n", mid_code[i].l, mid_code[i].a);
        }
        cout << endl;
    }
    void listtable()
    {
        cout << "listtable:" << endl;
        cout << "name" << "\t" << "kind" << "\t" << "level" << "\t" << "value" << "\t" << "address" << "\t" << "size" << endl;
        for(int k=0;k<table.size();k++)
        {
            cout << table[k].name << "\t";
            cout << table[k].kind << "\t";
            cout << table[k].level << "\t";
            cout << table[k].value << "\t";
            cout << table[k].address << "\t";
            cout << table[k].size << endl;
        }
        cout << endl;
    }
};

int main()
{
    cifa(t);
    yufa y;
    y.prog();
    if(goal == 0)
    {
        y.listcode();
        y.listtable();
        y.interpreter();
    }
    else
    {
        cout << "total error: " << err << " ��" << endl;
    }
}
